import React from 'react'

const Mrx = () => {
  return (
    <div>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        I am MRX
    </div>
  )
}

export default Mrx