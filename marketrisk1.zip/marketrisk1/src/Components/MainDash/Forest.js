import React from 'react'

const Forest = () => {
  return (
    <div>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        I am Forest
    </div>
  )
}

export default Forest