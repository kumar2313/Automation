import React from 'react'

const Venture = () => {
  return (
    <div>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        I am Venture
        
    </div>
  )
}

export default Venture